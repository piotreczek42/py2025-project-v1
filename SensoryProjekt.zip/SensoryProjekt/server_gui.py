import tkinter as tk
from tkinter import ttk, messagebox
import os
import yaml
from datetime import datetime
import threading

from server.server import NetworkServer

class NetworkServerGUI:
    def __init__(self, master):
        self.master = master
        master.title("Monitor sieciowy")
        master.geometry("1000x700")
        self.server = None
        self.server_thread = None

        self.gui_config_path = "gui_config.yaml"
        self.main_config_path = "config.yaml"
        self.load_gui_config()

        self._create_styles()
        self._create_widgets()
        self.update_gui_table()

    def load_gui_config(self):
        if os.path.exists(self.gui_config_path):
            with open(self.gui_config_path, 'r') as f:
                config = yaml.safe_load(f)
                self.initial_port = config.get('port', 9999)
        else:
            self.initial_port = 9999

    def save_gui_config(self):
        config = {'port': int(self.port_entry.get())}
        with open(self.gui_config_path, 'w') as f:
            yaml.dump(config, f)

    def _update_main_config_for_client(self, new_port: int):
        try:
            with open(self.main_config_path, 'r') as f:
                config = yaml.safe_load(f)
            if config is None:
                config = {}
            if 'client' not in config:
                config['client'] = {}
            config['client']['port'] = new_port
            with open(self.main_config_path, 'w') as f:
                yaml.dump(config, f)
            print(f"[INFO] Zaktualizowano {self.main_config_path}: client.port = {new_port}")
        except FileNotFoundError:
            messagebox.showwarning("Błąd konfiguracji", f"Nie znaleziono pliku {self.main_config_path}")
        except Exception as e:
            messagebox.showerror("Błąd zapisu", str(e))

    def _create_styles(self):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TButton", padding=8, relief="flat", background="#4a6", foreground="white", font=('Segoe UI', 9, 'bold'))
        style.configure("TLabel", padding=6, font=('Segoe UI', 9))
        style.configure("TEntry", padding=5, font=('Segoe UI', 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#555", foreground="white")
        style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        style.map("TButton", background=[("active", "#3a5")])
        style.configure("Status.TLabel", background="#e0e0e0", foreground="#333", font=('Segoe UI', 9, 'bold'), padding=8)

    def _create_widgets(self):
        # Main container using grid
        main_frame = ttk.Frame(self.master)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Control panel at top with grid
        control_frame = ttk.LabelFrame(main_frame, text="Sterowanie serwerem", padding=(15, 10))
        control_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        control_frame.columnconfigure(1, weight=1)

        # Port settings
        ttk.Label(control_frame, text="Port serwera:").grid(row=0, column=0, sticky="e", padx=(0, 5))
        self.port_entry = ttk.Entry(control_frame, width=10)
        self.port_entry.insert(0, str(self.initial_port))
        self.port_entry.grid(row=0, column=1, sticky="w", padx=(0, 20))

        # Buttons in a separate frame
        button_frame = ttk.Frame(control_frame)
        button_frame.grid(row=0, column=2, sticky="e", padx=(20, 0))

        self.start_button = ttk.Button(button_frame, text="▶ Uruchom serwer", command=self.start_server_gui)
        self.start_button.pack(side=tk.LEFT, padx=5)

        self.stop_button = ttk.Button(button_frame, text="■ Zatrzymaj serwer", command=self.stop_server_gui, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)

        # Data table with scrollbars
        table_frame = ttk.Frame(main_frame)
        table_frame.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        main_frame.rowconfigure(1, weight=1)

        # Add scrollbars
        tree_scroll_y = ttk.Scrollbar(table_frame)
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        tree_scroll_x = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL)
        tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

        self.tree = ttk.Treeview(
            table_frame,
            columns=("Sensor", "Wartosc", "Jednostka", "Timestamp", "Sr1h", "Sr12h"),
            show="headings",
            yscrollcommand=tree_scroll_y.set,
            xscrollcommand=tree_scroll_x.set
        )
        self.tree.pack(fill=tk.BOTH, expand=True)

        tree_scroll_y.config(command=self.tree.yview)
        tree_scroll_x.config(command=self.tree.xview)

        # Configure columns
        headings = {
            "Sensor": {"text": "Czujnik", "width": 120},
            "Wartosc": {"text": "Wartość", "width": 100},
            "Jednostka": {"text": "Jednostka", "width": 80},
            "Timestamp": {"text": "Czas pomiaru", "width": 150},
            "Sr1h": {"text": "Średnia 1h", "width": 100},
            "Sr12h": {"text": "Średnia 12h", "width": 100}
        }

        for col, settings in headings.items():
            self.tree.heading(col, text=settings["text"])
            self.tree.column(col, width=settings["width"], anchor=tk.CENTER)

        # Status bar at bottom
        self.status_label = ttk.Label(
            self.master,
            text="Stan: Serwer zatrzymany",
            style="Status.TLabel",
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def update_status(self, message):
        self.master.after(0, lambda: self.status_label.config(text=f"Stan: {message}"))

    def on_closing(self):
        if messagebox.askokcancel("Wyjście", "Zamknąć serwer?"):
            self.stop_server_gui()
            self.save_gui_config()
            self.master.destroy()

    def start_server_gui(self):
        try:
            port = int(self.port_entry.get())
            if not (1024 <= port <= 65535):
                raise ValueError("Podaj port z zakresu 1024-65535.")

            self.server = NetworkServer(port)
            self.server.register_new_data_callback(self.on_new_sensor_data)
            self.server.register_status_callback(self.update_status)

            self.server_thread = threading.Thread(target=self.server.start, daemon=True)
            self.server_thread.start()

            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.port_entry.config(state=tk.DISABLED)
            self.update_status(f"Serwer działa na porcie {port}")

            self._update_main_config_for_client(port)

        except ValueError as e:
            messagebox.showerror("Błąd", str(e))
        except Exception as e:
            messagebox.showerror("Błąd uruchamiania", str(e))
            self.update_status(f"Błąd: {e}")
            self.stop_server_gui()

    def stop_server_gui(self):
        if self.server:
            self.server.stop()
            self.server = None
            self.server_thread = None
            self.update_status("Serwer zatrzymany")

        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.port_entry.config(state=tk.NORMAL)

    def on_new_sensor_data(self, *args, **kwargs):
        pass

    def update_gui_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        if self.server and self.server.aggregator:
            sensor_ids = sorted(self.server.aggregator.get_all_sensor_ids())
            for s_id in sensor_ids:
                last_val = self.server.aggregator.get_last_value(s_id)
                if last_val:
                    val = last_val['value']
                    unit = last_val['unit']
                    ts = last_val['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
                    avg1 = self.server.aggregator.get_average(s_id, 1)
                    avg12 = self.server.aggregator.get_average(s_id, 12)
                    self.tree.insert("", tk.END, values=(s_id, f"{val:.2f}", unit, ts, f"{avg1:.2f}", f"{avg12:.2f}"))

        self.master.after(2000, self.update_gui_table)

if __name__ == "__main__":
    root = tk.Tk()
    app = NetworkServerGUI(root)
    root.mainloop()